import React, {useEffect, useState} from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import axios from 'axios'
import '../styles/Department.css'


function Department() {
    const navigate = useNavigate()
    const {departmentName} = useParams()
    const [employees, setEmployees] = useState([])
    const [search, setSearch] = useState('');
    const [loading, setLoading] = useState(true);
      const [newEmployee, setNewEmployee] = useState({
        name: '',
        surname: '',
        gender: '',
        department: '',
        salary: ''
      });
    const [selectedEmployee, setSelectedEmployee] = useState(null);
    const [showModal, setShowModal] = useState(false);

      const handleModalUpdate = () => {
        axios.put(`http://localhost:5000/api/employees/${selectedEmployee.id}`, selectedEmployee)
          .then(res => {
            setEmployees(prev =>
              prev.map(emp => (emp.id === selectedEmployee.id ? res.data : emp))
            );
            setShowModal(false);
            setSelectedEmployee(null);
          })
          .catch(err => console.error('Update failed', err));
      };
    
      const handleModalDelete = () => {
        if (window.confirm('Are you sure you want to delete this employee?')) {
          axios.delete(`http://localhost:5000/api/employees/${selectedEmployee.id}`)
            .then(() => {
              setEmployees(prev => prev.filter(emp => emp.id !== selectedEmployee.id));
              setShowModal(false);
              setSelectedEmployee(null);
            })
            .catch(err => console.error('Delete failed', err));
        }
      };
    
      const filteredEmployees = employees.filter(emp =>
        emp.name.toLowerCase().includes(search.toLowerCase())
      );
    

    useEffect(() => {
        setLoading(true);
        axios.get('http://localhost:5000/api/employees')
            .then(response => {
                const filteredEmployees = response.data.filter(employee => employee.department.toLowerCase() === departmentName.toLowerCase())
                setEmployees(filteredEmployees)
                setLoading(false)
            })
            .catch(error => {
                console.error('There was an error fetching the data!', error);
                setLoading(false)
            })
    }, [departmentName])

  return (
    <div>
        <h2>Employees in {departmentName} Department</h2>
        {/* Search */}
        <input
            type="text"
            placeholder="Search by name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="search-bar"
        />

        <p>*Click on an employee to edit or delete their details</p>
        
        {loading ? (
        <div className="spinner"></div>
      ) : (
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Surname</th>
              <th>Gender</th>
              <th>Department</th>
              <th>Salary</th>
            </tr>
          </thead>
          <tbody>
            {filteredEmployees.map(employee => (
              <tr
                key={employee.id}
                onClick={() => {
                  setSelectedEmployee({ ...employee });
                  setShowModal(true);
                }}
                style={{ cursor: 'pointer' }}
              >
                <td>{employee.id}</td>
                <td>{employee.name}</td>
                <td>{employee.surname}</td>
                <td>{employee.gender}</td>
                <td>{employee.department}</td>
                <td>R{employee.salary}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )} 

      {/* Modal */}
      {showModal && selectedEmployee && (
        <div className="modal-backdrop">
          <div className="modal">
            <h3 style={{textAlign: 'center'}}>Edit Employee 🧑‍💼</h3>
            <p style={{marginLeft: '10px'}}>Employee ID: {selectedEmployee.id}</p>
            <input name="name" value={selectedEmployee.name} onChange={(e) => setSelectedEmployee({ ...selectedEmployee, name: e.target.value })} />
            <input name="surname" value={selectedEmployee.surname} onChange={(e) => setSelectedEmployee({ ...selectedEmployee, surname: e.target.value })} />
            <input name="gender" value={selectedEmployee.gender} onChange={(e) => setSelectedEmployee({ ...selectedEmployee, gender: e.target.value })} />
            <input name="department" value={selectedEmployee.department} onChange={(e) => setSelectedEmployee({ ...selectedEmployee, department: e.target.value })} />
            <input name="salary" type="number" value={selectedEmployee.salary} onChange={(e) => setSelectedEmployee({ ...selectedEmployee, salary: e.target.value })} />
            <div className="modal-buttons">
              <button onClick={handleModalUpdate}>Update</button>
              <button onClick={handleModalDelete}>Delete</button>
              <button onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      <button onClick={() => navigate('/employees')} style={{marginBottom: '20px', border: 'none', color: '#1e1e2f', cursor: 'pointer'}}>← Back to All Employees</button>

    </div>
  )
}

export default Department