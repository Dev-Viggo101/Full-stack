import React from 'react'

function Home() {
  return (
    <div>
        <h2>Welcome to the Employee Directory</h2>
        <p>Use the navigation links to view all employees or filter by department.</p>
    </div>
  )
}

export default Home