import '../styles/App.css';
import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Routes, Link, useNavigate } from 'react-router-dom';
import Home from '../components/Home';
import Employees from '../components/Employee';
import Department from '../components/Department';
import axios from "axios";

function App() {
  return (
    <Router>
      <div className="app">
        <Navigation />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/employees" element={<Employees />} />
          <Route path="/department/:departmentName" element={<Department />} />
        </Routes>
      </div>
    </Router>
  );
}

function Navigation() {
  const navigate = useNavigate();
  const [selectedDept, setSelectedDept] = useState('');
  const [departments, setDepartments] = useState([])

  useEffect(() => {
    axios.get('http://localhost:5000/api/departments')
      .then(res => setDepartments(res.data))
      .catch(err => console.error("Failed to catch departments", err))
  })

  const handleDeptChange = (e) => {
    const dept = e.target.value;
    setSelectedDept(dept);
    if (dept) {
      navigate(`/department/${dept.toLowerCase()}`);
    }
  };

  return (
    <nav>
      <ul>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/employees">All Employees</Link></li>
        <li>
          <select value={selectedDept} onChange={handleDeptChange}>
            <option value="">Select Department</option>
            {departments.map((dept, index) => (
              <option key={index} value={dept}>{dept}</option>
            ))}
          </select>
        </li>
      </ul>
    </nav>
  );
}

export default App;

