const mongoose = require('mongoose')

const employeeSchema = new mongoose.Schema({
    id: {
        type: Number,
        required: true,
        unique: true
    },
    name: {
        type: String,
        required: true,
        minlength: 3
    },
    surname: {
        type: String,
        required: true,
        minlength: 3
    },
    gender: {
        type: String,
        required: true,
        enum: ["Female", "Male"]
    },
    department: {
        type: String,
        required: true,
    },
    salary: {
        type: Number,
        required: true,
    }
})

module.exports = mongoose.model("employees", employeeSchema)