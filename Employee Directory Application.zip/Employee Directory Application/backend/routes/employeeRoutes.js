const express = require('express')
const employeesRouter = express.Router()

const Employee = require('../models/employee')

const getNextId = async () => {
    const last = await Employee.findOne().sort({id: -1})
    return last ? last.id + 1 : 1
}

//POST
employeesRouter.post('/api/employees', async (req, res) => {
    
    const {name, surname, gender, department, salary} = req.body

    if(!name || !surname || !gender || !department || !salary){
        return res.status(400).json({error: "All fields are required"})
    }

    const newEmployee = new Employee({
        id: await getNextId(),
        name,
        surname,
        gender,
        department,
        salary
    })

    try{
        await newEmployee.save()
        res.status(201).json(newEmployee)
    }
    catch(error){
        res.status(500).json({error: "Failed to save employee", details: error})
    }

})

//GET all employees
// GET employees (all or by department)
employeesRouter.get('/api/employees', async (req, res) => {
  const { department } = req.query;

  // Build query object
  const query = department
    ? { department: new RegExp(`^${department}$`, 'i') } // case-insensitive match
    : {};

  try {
    const employees = await Employee.find(query);
    res.status(200).json(employees);
  } catch (error) {
    console.error("❌ Error fetching employees:", error.message);
    res.status(500).json({ error: 'Failed to fetch employees' });
  }
});


//GET employees by department
employeesRouter.get('/api/departments', async (req, res) => {
  try {
    const departments = await Employee.distinct('department');
    res.status(200).json(departments);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch departments' });
  }
});

//PUT
employeesRouter.put('/api/employees/:id', async (req, res) => {
    const {id} = req.params
    const {name, surname, gender, department, salary} = req.body

    try{
        const updatedEmployee = await Employee.findOneAndUpdate(
            {id: parseInt(id)},
            {name, surname, gender, department, salary},
            {new: true}
        )

        if(!updatedEmployee) return res.status(404).json({error: 'Employee not found'})
        res.status(200).json(updatedEmployee)
    }
    catch (error){
        res.status(400).json({error: error.message})
    }
})

//DELETE 
employeesRouter.delete('/api/employees/:id', async (req, res) => {
    const {id} = req.params

    try{
        const deletedEmployee = await Employee.findOneAndDelete({id: parseInt(id)})

        if(!deletedEmployee) return res.status(404).json({error: 'Employee not found'})
        res.status(200).json(deletedEmployee)
    }
    catch (error){
        res.status(500).json({error: error.message})
    }
})

module.exports = employeesRouter