const express = require('express')
const cors = require('cors')
const mongoose = require('mongoose')
const app = express()
const port = 5000
const db_url = 'mongodb://localhost:27017/employees'

// Middleware
app.use(cors())
app.use(express.json())

// Database Connection
mongoose.connect(db_url)
const db = mongoose.connection
db.on('error', (error) => console.error('Database Error: ', error))
db.once('open', () => console.log('Connected to MongoDB'))

// Routes
const employeesRouter = require('./routes/employeeRoutes')
app.use(employeesRouter)

// Start server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
})