import { useEffect, useState } from "react"
import axios from "axios"
import ContactItem from "./ContactItem"

export default function ContactList() {
  const [contacts, setContacts] = useState([])

  const fetchContacts = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/contacts")
      setContacts(res.data)
    } catch (err) {
      console.error("Error fetching contacts", err)
    }
  }

  useEffect(() => {
    fetchContacts()
  }, [])

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/contacts/${id}`)
      setContacts(contacts.filter((c) => c.id !== id))
    } catch (err) {
      console.error("Error deleting contact", err)
    }
  }

  return (
    <div>
      <h2>Contacts</h2>
      {contacts.length === 0 ? (
        <p>No contacts found</p>
      ) : (
        contacts.map((contact) => (
          <ContactItem
            key={contact.id}
            contact={contact}
            onDelete={handleDelete}
          />
        ))
      )}
    </div>
  )
}
