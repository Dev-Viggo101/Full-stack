import { Link } from "react-router-dom"

export default function ContactItem({ contact, onDelete }) {
  return (
    <div style={{ border: "1px solid #ccc", margin: "10px", padding: "10px" }}>
      <p><strong>Name:</strong> {contact.name}</p>
      <p><strong>Email:</strong> {contact.email}</p>
      <p><strong>Phone:</strong> {contact.phone}</p>
      <Link to={`/edit/${contact.id}`}>
        <button>Edit</button>
      </Link>
      <button onClick={() => onDelete(contact.id)} style={{ marginLeft: "10px" }}>
        Delete
      </button>
    </div>
  )
}
