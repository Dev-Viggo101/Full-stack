import ContactList from "../components/ContactList"

export default function Home() {
  return (
    <div>
      <h1>Contact Manager</h1>
      <ContactList />
    </div>
  )
}
