import { useEffect, useState } from "react"
import { useParams, useNavigate } from "react-router-dom"
import axios from "axios"
import ContactForm from "../components/ContactForm"

export default function EditContact() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [contact, setContact] = useState(null)

  useEffect(() => {
    const fetchContact = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/contacts")
        const found = res.data.find((c) => c.id === parseInt(id))
        setContact(found)
      } catch (err) {
        console.error("Error fetching contact", err)
      }
    }
    fetchContact()
  }, [id])

  const handleUpdate = async (data) => {
    try {
      await axios.put(`http://localhost:5000/api/contacts/${id}`, data)
      navigate("/")
    } catch (err) {
      console.error("Error updating contact", err)
    }
  }

  return (
    <div>
      <h2>Edit Contact</h2>
      {contact ? (
        <ContactForm initialData={contact} onSubmit={handleUpdate} />
      ) : (
        <p>Loading...</p>
      )}
    </div>
  )
}
