import { useNavigate } from "react-router-dom"
import axios from "axios"
import ContactForm from "../components/ContactForm"

export default function AddContact() {
  const navigate = useNavigate()

  const handleAdd = async (data) => {
    try {
      await axios.post("http://localhost:5000/api/contacts", data)
      navigate("/")
    } catch (err) {
      console.error("Error adding contact", err)
    }
  }

  return (
    <div>
      <h2>Add Contact</h2>
      <ContactForm onSubmit={handleAdd} />
    </div>
  )
}
