import { Routes, Route, Link } from "react-router-dom"
import Home from "./pages/Home"
import AddContact from "./pages/AddContact"
import EditContact from "./pages/EditContact"
import './App.css'

export default function App() {
  return (
    <div className="container">
      <nav style={{ marginBottom: "20px" }}>
        <Link to="/">Home</Link> |{" "}
        <Link to="/add">Add Contact</Link>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/add" element={<AddContact />} />
        <Route path="/edit/:id" element={<EditContact />} />
      </Routes>
    </div>
  )
}
