const express = require('express')
const ContactManagerRouter = express.Router()

const Contact = require('../models/Contact')

const getNextId = async () => {
    const last = await Contact.findOne().sort({id: -1})
    return last ? last.id + 1 : 1
}

ContactManagerRouter.get('/api/contacts', async (req, res) => {
    try{
        const contacts = await Contact.find()
        res.status(200).json(contacts)
    }
    catch(error){
        res.status(500).json({error: 'Failed to fetch all contacts'})
    }
})

ContactManagerRouter.post('/api/contacts', async (req, res) => {
    const {name, email, phone} = req.body

    if(!name || !email || !phone){
        return res.status(400).json({error: "All fields are required!"})
    }

    const newContact = new Contact({
        id: await getNextId(),
        name,
        email,
        phone
    })

    try{
        await newContact.save()
        res.status(201).json(newContact)
    }
    catch(error){
        res.status(500).json({error: "Failed to save contact", details: error})
    }
})

ContactManagerRouter.put('/api/contacts/:id', async (req, res) => {
    const {id} = req.params
    const {name, email, phone} = req.body

    try{
        const updateContact = await Contact.findOneAndUpdate(
            {id: parseInt(id)},
            {$set: req.body},
            {new: true, runValidators: true}
        )
        if(!updateContact) return res.status(404).json({error: 'Contact not found'})
        res.status(200).json(updateContact)
    }
    catch(error){
        res.status(400).json({error: error.message})
    }
})

ContactManagerRouter.delete('/api/contacts/:id', async (req, res) => {
    const {id} = req.params

    try{
        const deletedContact = await Contact.findOneAndDelete({id: parseInt(id)})

        if(!deletedContact) return res.status(404).json({error: 'Employee not found'})
        res.status(200).json(deletedContact)
    }
    catch(error){
        res.status(500).json({error: error.message})
    }
})

module.exports = ContactManagerRouter