const mongoose = require('mongoose')

const contactSchema = new mongoose.Schema({
    id:{
        type: Number,
        required: true,
        unique: true
    },
    name:{
        type: String,
        required: true,
        minlength: 1
    },
    email:{
        type: String,
        required: true,
        match: /.+\@.+\..+/
    },
    phone:{
        type: String,
        required: true,
        minlength: 10,
        maxlength: 10
    }
})

module.exports = mongoose.model("Contact", contactSchema)