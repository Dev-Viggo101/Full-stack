import { loadStripe } from "@stripe/stripe-js"

const stripePromise = loadStripe("pk_test_51S7trv89b1DlOV2cifkwvK2I0YYFvMz1ZeEARuj72mJ4u1eaGXpkPTMgOkjmeC5lWeKc1SGXc4bwBxx1p75fEgPm00vum8rMK0")

const plans = [
    {id: 1, type: "Basic Plan", amount: "$5", priceId: "price_1S7txc89b1DlOV2ceZkZjAjJ" ,perks: ["✅ Basic features access", "✅ 5 Projects per month", "✅ Community support", "✅ Weekly updates"]},
    {id: 2, type: "Premium Plan", amount: "$15", priceId: "price_1S7tyY89b1DlOV2ciIVCkKn8",perks: ["✅ All basic features", "✅ Unlimited projects", "✅ Priority support", "✅ Daily updates", "✅ Advanced analytics"]},
]

function Card() {

    const handleSubscribe = async (priceId) => {
        const stripe = await stripePromise

        const res = await fetch("http://localhost:5000/create-checkout-session", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ priceId })
        })

        const { url } = await res.json()
        window.location.href = url
    }

  return (
    <div>

        <h1>Choose Your Plan</h1> 
        <p>Simple pricing for everyone</p> 

        <div id="planDiv">

            {plans.map((plan) => (
                <div key={plan.id} id="plan">
                    <h2>{plan.type}</h2>

                    <h2 style={{marginTop: "-5px",}}>{plan.amount}<sub>/month</sub></h2>

                    <ul>
                        {plan.perks.map((desc, index) => (
                            <li key={index}>{desc}</li>
                        ))}
                    </ul>

                <button onClick={() => handleSubscribe(plan.priceId)}>Subscribe Now</button>

                </div>
            ))}  
            
        </div>  

    </div>
  )
}

export default Card