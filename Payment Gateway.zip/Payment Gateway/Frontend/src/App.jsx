import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import Success from "./pages/Success"
import Cancel from "./pages/Cancel"
import SubPlan from './pages/SubPlan'
import './App.css'

function App() {

  return (
    <Router>
      <Routes>
        <Route path="/" element={<SubPlan />} />
        <Route path="/success" element={<Success />} />
        <Route path="/cancel" element={<Cancel />} />
      </Routes>
    </Router>
  )
}

export default App
