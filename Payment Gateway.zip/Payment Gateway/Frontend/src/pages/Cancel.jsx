function Cancel() {
  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
        <h1>⚠️ Payment Canceled</h1>
        <p>Your payment was canceled. No charges were made.</p>
        <a href="/">Go back and try again</a>
    </div>
  )
}

export default Cancel