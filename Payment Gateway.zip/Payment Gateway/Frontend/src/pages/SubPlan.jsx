import Card from "../components/Card"

function SubPlan() {
  return (
    <Card />
  )
}

export default SubPlan