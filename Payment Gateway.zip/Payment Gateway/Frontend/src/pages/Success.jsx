function Success() {
  return (
    <div style={{textAlign: "center", marginTop: "100px"}}>
        <h1>🎉 Payment Successful</h1>
        <p>Thank you for subscribing. Your plan is now active.</p>
        <a href="/">Go back to Home</a>
    </div>
  )
}

export default Success